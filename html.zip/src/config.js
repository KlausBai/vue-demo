export const backendConfig/** 模拟为后台获取的数据 */ = [
    {
        blockName:'first',
        functionName:'setServiceLabel'
    },
    {
        blockName: 'second',
        functionName:'commonSearch'
    },
    {
        blockName:'third',
        functionName:'addSolution'
    }
]
